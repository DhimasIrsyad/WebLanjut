-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.30 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table app_template_db.messages
CREATE TABLE IF NOT EXISTS `messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL,
  `pesan` longtext,
  `user_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_c158f711-f66d-4403-9179-99d32a57525f` (`user_id`),
  CONSTRAINT `FK_c158f711-f66d-4403-9179-99d32a57525f` FOREIGN KEY (`user_id`) REFERENCES `user` (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table app_template_db.messages: ~1 rows (approximately)
DELETE FROM `messages`;
INSERT INTO `messages` (`id`, `judul`, `file`, `pesan`, `user_id`) VALUES
	(2, 'Est aliquid quia do', NULL, 'Consequatur Dolor b', 2);

-- Dumping structure for table app_template_db.notifications
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `gambar` varchar(255) DEFAULT NULL,
  `deskripsi` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table app_template_db.notifications: ~0 rows (approximately)
DELETE FROM `notifications`;

-- Dumping structure for table app_template_db.user
CREATE TABLE IF NOT EXISTS `user` (
  `no` int NOT NULL AUTO_INCREMENT,
  `nama_lengkap` varchar(100) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `role` varchar(100) DEFAULT NULL,
  `no_telp` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table app_template_db.user: ~3 rows (approximately)
DELETE FROM `user`;
INSERT INTO `user` (`no`, `nama_lengkap`, `password`, `role`, `no_telp`) VALUES
	(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'administrator', '0829489394'),
	(2, 'user', 'ee11cbb19052e40b07aac0ca060c23ee', 'user', '382398238'),
	(3, 'Dolore eu voluptas q', '5f4dcc3b5aa765d61d8327deb882cf99', 'user', '1693249032');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
