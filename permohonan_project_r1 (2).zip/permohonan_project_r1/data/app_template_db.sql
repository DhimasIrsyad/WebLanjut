-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.14-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for app_template_db
CREATE DATABASE IF NOT EXISTS `app_template_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `app_template_db`;

-- Dumping structure for table app_template_db.messages
CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pesan` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_c158f711-f66d-4403-9179-99d32a57525f` (`user_id`),
  CONSTRAINT `FK_c158f711-f66d-4403-9179-99d32a57525f` FOREIGN KEY (`user_id`) REFERENCES `user` (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table app_template_db.messages: ~4 rows (approximately)
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` (`id`, `judul`, `file`, `pesan`, `user_id`) VALUES
	(2, 'Est aliquid quia do', NULL, 'Consequatur Dolor b', 2),
	(3, 'perpanjang ktp', 'Poster.pdf', 'halo', 4),
	(4, 'surat keterangan', NULL, 'test', 5),
	(5, 'KTP HILANG', 'jurnaladm,+197-199+-+calvin+geraldy.pdf', 'ingin membuat ktp baru', 6);
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;

-- Dumping structure for table app_template_db.notifications
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gambar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deskripsi` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table app_template_db.notifications: ~5 rows (approximately)
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` (`id`, `gambar`, `deskripsi`) VALUES
	(1, '1670484965-SISTEM_KOMUNIKASI.png', '                                                 '),
	(2, '1670490690-kerja_bakti.jpeg', 'a'),
	(3, '1670490910-posyandu.jpg', 'p'),
	(4, '1670906825-Anjing-Maltese.jpg', 'anjing 1anjing 2 anjing 3'),
	(5, '1670907145-vanet.jpg', NULL);
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;

-- Dumping structure for table app_template_db.user
CREATE TABLE IF NOT EXISTS `user` (
  `no` int(11) NOT NULL AUTO_INCREMENT,
  `nama_lengkap` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_telp` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`no`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Dumping data for table app_template_db.user: ~6 rows (approximately)
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`no`, `nama_lengkap`, `password`, `role`, `no_telp`) VALUES
	(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'administrator', '0829489394'),
	(2, 'user', 'ee11cbb19052e40b07aac0ca060c23ee', 'user', '382398238'),
	(3, 'Dolore eu voluptas q', '5f4dcc3b5aa765d61d8327deb882cf99', 'user', '1693249032'),
	(4, 'faris', 'c73f227db1b523334ea3aef35bf06af8', 'user', '085764483785'),
	(5, 'William', 'bf1bd52596d9afbdfa581336b3152b49', 'user', '081394481888'),
	(6, 'Irham Nugraha', '0884d3007f1937b76b2e6548a17f36a5', 'user', '08882011202');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
