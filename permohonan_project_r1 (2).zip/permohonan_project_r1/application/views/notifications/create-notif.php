<!-- edit content start here-->

<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Buat Pemberitahuan</h1>
    </div>

    <div class="card shadow mb-4">
        <div class="card-body">
            <form enctype="multipart/form-data" method="POST" action="<?= base_url('/notifications/store') ?>">
                <div class="form-group row">
                    <label for="file" class="col-sm-2 col-form-label">Sisipkan Gambar</label>
                    <div class="col-sm-10">
                        <input type="file" class="form-control" id="file" name="file" placeholder="Sisipkan Gambar" required autofocus>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="deskripsi" class="col-sm-2 col-form-label">Deskripsi</label>
                    <div class="col-sm-10">
                        <textarea class="form-control" name="deskripsi" id="deskripsi" placeholder="Deskripsi pemberitahuan" cols="30" rows="10"></textarea>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-10">
                        <button type="submit" class="btn btn-success">Tambah Pemberitahuan</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>