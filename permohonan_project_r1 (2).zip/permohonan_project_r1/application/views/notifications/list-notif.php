<!-- edit content start here-->

<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Daftar Pemberitahuan</h1>
        <a href="<?= base_url('/notifications/create') ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Buat Pemberitahuan</a>
    </div>

    <?php if ($this->session->flashdata('new-notif')) : ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Info!</strong> <?= $this->session->flashdata('new-notif'); ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Gambar</th>
                            <th>Deskripsi</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($notifications)) : ?>
                            <tr>
                                <td colspan="3">Tidak ada pesan</td>
                            </tr>
                        <?php else : ?>
                            <?php foreach ($notifications as $notif) : ?>
                                <tr>
                                    <td><img src="<?= base_url('/uploads/notifications/' . $notif->gambar) ?>" alt="Gambar Pemberitahuan" class="img-fluid" width="300px"></td>
                                    <td><?= $notif->deskripsi ?? 'Tidak ada deskripsi' ?></td>
                                    <td class="text-center">
                                        <a href="<?= base_url('/notifications/edit/' . $notif->id) ?>" class="btn btn-sm btn-warning">Edit</a>
                                        <form id="form-delete-<?= $notif->id ?>" action="<?= base_url('/notifications/delete') ?>" method="post" class="d-none">
                                        <input type="hidden" name="id" value="<?= $notif->id ?>">
                                        </form>
                                        <button class="btn btn-sm btn-danger btn-delete" onclick="deleteNotif('<?= $notif->id ?>')">Delete</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    function deleteNotif(id){
        if(confirm('Yakin hapus pemberitahuan?')){
            document.getElementById(`form-delete-${id}`).submit();
        }
    }
</script>