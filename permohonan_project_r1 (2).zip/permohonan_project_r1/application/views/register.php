<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<title>Register Page</title>

	<!-- Bootstrap core CSS -->
	<link href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>" rel="stylesheet">
	<!-- Custom styles for Login -->
	<link href="<?php echo base_url('assets/css/login.css'); ?>" rel="stylesheet">

</head>

<body>
	<form class="form-signin" method="post" action="<?php echo site_url('/register/daftar'); ?>">
		<div class="text-center mb-4">
			<svg width="3em" height="3em" viewBox="0 0 16 16" class="bi bi-briefcase-fill" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
				<path fill-rule="evenodd" d="M0 12.5A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5V6.85L8.129 8.947a.5.5 0 0 1-.258 0L0 6.85v5.65z" />
				<path fill-rule="evenodd" d="M0 4.5A1.5 1.5 0 0 1 1.5 3h13A1.5 1.5 0 0 1 16 4.5v1.384l-7.614 2.03a1.5 1.5 0 0 1-.772 0L0 5.884V4.5zm5-2A1.5 1.5 0 0 1 6.5 1h3A1.5 1.5 0 0 1 11 2.5V3h-1v-.5a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5V3H5v-.5z" />
			</svg>
			<h1 class="h3 mb-3 font-weight-normal">Pendaftaran Akun Warga RW 09 Cikutra</h1>
		</div>

		<?php if (validation_errors() != '') : ?>
			<div class="alert alert-danger alert-dismissible fade show" role="alert">
				<strong>Error!</strong> <?= validation_errors(); ?>
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
		<?php endif; ?>

		<div class="form-label-group">
			<input type="text" id="nama_lengkap" name="nama_lengkap" class="form-control" placeholder="Nama Lengkap" required autofocus value="<?= set_value('nama_lengkap') ?>">
			<label for="nama_lengkap">Nama Lengkap</label>
		</div>

		<div class="form-label-group">
			<input type="number" id="no_telp" name="no_telp" class="form-control" placeholder="No Telpon" required autofocus value="<?= set_value('no_telp') ?>">
			<label for="no_telp">No Telepon</label>
		</div>

		<div class="form-label-group">
			<input type="password" id="inputPassword" name="password" class="form-control" placeholder="Password" required>
			<label for="inputPassword">Kata Sandi</label>
		</div>

		<div class="form-label-group">
			<input type="password" id="inputPasswordConfirmation" name="passwordConfirmation" class="form-control" placeholder="Password" required>
			<label for="inputPasswordConfirmation">Ulangi Kata Sandi</label>
		</div>

		<div class="checkbox">
			<p>Sudah memiliki akun? <a href="<?= base_url('/Login') ?>">klik di sini</a></p>
		</div>
		<button class="btn btn-lg btn-primary btn-block" type="submit">Sign up</button>
		<p class="mt-5 mb-3 text-muted text-center"> Copyright &copy; - Itenas (Group A10) <?php echo date("Y"); ?></p>
	</form>
</body>

</html>