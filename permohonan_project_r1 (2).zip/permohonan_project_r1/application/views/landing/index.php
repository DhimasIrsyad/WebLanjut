<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SISTEM KOMUNIKASI RW 09 CIKUTRA</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <link rel="stylesheet" href="<?= base_url('/landing/sytle.css') ?>">
</head>

<body>
    <nav class="navbar navbar-expand-lg mb-4 top-bar navbar-static-top sps sps--abv">
        <div class="container">
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarCollapse1" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <a class="navbar-brand mx-auto" href="#">SISTEM KOMUNIKASI RW 09 CIKUTRA</span></a>
            <div class="collapse navbar-collapse" id="navbarCollapse1">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active"> <a class="nav-link" href="#myCarousel">Beranda <span class="sr-only">(current)</span></a> </li>
                    <li class="nav-item"> <a class="nav-link" href="#benefits">Berita Kegiatan</a> </li>
                    <li class="nav-item"> <a class="nav-link" href="#about">Tentang</a> </li>
                    <li class="nav-item"> <a class="nav-link" href="<?= base_url('/Login') ?>">Masuk</a> </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Swiper Silder
    ================================================== -->
    <!-- Slider main container -->
    <div class="swiper-container main-slider" id="myCarousel">
        <div class="swiper-wrapper">
            <?php foreach ($notifications as $notif) : ?>
                <div class="swiper-slide slider-bg-position" style="background:url('<?= base_url('/uploads/notifications/' . $notif->gambar) ?>')" data-hash="slide1">
                    <h2 class="text-dark"><?= $notif->deskripsi ?></h2>
                </div>
            <?php endforeach; ?>
        </div>
        <!-- Add Pagination -->
        <div class="swiper-pagination"></div>
        <!-- Add Navigation -->
        <div class="swiper-button-prev"><i class="fa fa-chevron-left"></i></div>
        <div class="swiper-button-next"><i class="fa fa-chevron-right"></i></div>
    </div>

    <section class="service-sec" id="benefits">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12">
                    <div class="heading">
                        <h2>Berita Kegiatan</h2>
                    </div>
                </div>
                <div class="col-md-12 col-sm-12">
                    <div class="row">
                        <div class="col-md-6 col-sm-12 text-sm-center service-block"> <i class="fa fa-plus" aria-hidden="true"></i>
                            <h3>Program Kerja Bakti Mingguan</h3>
                            <p>Kerja bakti merupakan salah satu rutinitas budaya pada RW 09 Cikutra.
                                Tujuan kegiatan ini adalah untuk membangun lingkungan yang asri, maju dan sejahtera.</p>
                        </div>
                        <div class="col-md-6 col-sm-12 text-sm-center service-block"> <i class="fa fa-leaf" aria-hidden="true"></i>
                            <h3>Program Posyandu</h3>
                            <p>Posyandu merupakan salah satu bentuk Upaya Kesehatan Berbasis Masyarakat (UKBM).
                                Tujuan kegiatan ini adalah memberikan pelayanan kesehatan dasar dalam aspek pemantauan tumbuh kembang anak.</p>
                        </div>
                        <div class="col-md-6 col-sm-12 text-sm-center service-block"> <i class="fa fa-leaf" aria-hidden="true"></i>
                            <h3>Program Olahraga Bersama</h3>
                            <p>Tujuan kegiatan ini adalah untuk menerapkan gaya hidup yang sehat di lingkungan RW 09 yang diselenggarakan
                                setiap minggu.</p>
                        </div>
                        <div class="col-md-6 col-sm-12 text-sm-center service-block"> <i class="fa fa-bell" aria-hidden="true"></i>
                            <h3>Program Siskamling</h3>
                            <p>Tujuan kegiatan ini adalah untuk menciptakan situasi dan kondisi yang aman, tertib, dan tentram di lingkungan
                                RW 09.</p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div>
    </section>

    <!-- About 
    ================================================== -->
    <section class="about-sec parallax-section" id="about">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <h2><small>Who We Are</small>About<br>
                        Our Blog</h2>
                </div>
                <div class="col-md-4">
                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Autem iste aspernatur architecto odio iure, quisquam reiciendis dolorum possimus exercitationem vel. Dolore dolorum aspernatur quidem nesciunt rerum mollitia placeat, voluptatum porro.</p>
                </div>
                <div class="col-md-4">
                    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Autem iste aspernatur architecto odio iure, quisquam reiciendis dolorum possimus exercitationem vel. Dolore dolorum aspernatur quidem nesciunt rerum mollitia placeat, voluptatum porro.</p>
                    <p><a href="<?= base_url('https://maps.app.goo.gl/GkCuXmWN3RcJqqM78?g_st=iw') ?>" class="btn btn-transparent-white btn-capsul">Explore More</a></p>
                </div>
            </div>
        </div>
    </section>

    <script src="<?= base_url('/landing/script.js') ?>"></script>
</body>

</html>