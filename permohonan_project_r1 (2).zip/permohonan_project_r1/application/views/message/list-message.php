<!-- edit content start here-->

<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Daftar Pesan</h1>
        <?php if($this->session->userdata('role') == 'user') : ?>
            <a href="<?= base_url('/message/create') ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i class="fas fa-download fa-sm text-white-50"></i> Kirim Pesan</a>
        <?php endif; ?>
    </div>

    <?php if ($this->session->flashdata('sendMessage')) : ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Info!</strong> <?= $this->session->flashdata('sendMessage'); ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Judul</th>
                            <th>File</th>
                            <th>Pesan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($messages)) : ?>
                            <tr>
                                <td colspan="3">Tidak ada pesan</td>
                            </tr>
                        <?php else : ?>
                            <?php foreach ($messages as $message) : ?>
                                <tr>
                                    <td><?= $message->judul ?? 'Tidak ada judul permohonan' ?></td>
                                    <?php if ($message->file) : ?>
                                        <td><a target="_blank" href="<?= base_url('/uploads/files/' . $message->file) ?>"><?= $message->file ?></a></td>
                                    <?php else : ?>
                                        <td>Tidak ada file permohonan</td>
                                    <?php endif; ?>
                                    <td><?= $message->pesan ?? 'Tidak ada konten permohonan' ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>