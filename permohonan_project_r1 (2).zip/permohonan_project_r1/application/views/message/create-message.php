<!-- edit content start here-->

<div class="container-fluid">
    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Buat Permohonan</h1>
    </div>

    <div class="card shadow mb-4">
        <div class="card-body">
            <form enctype="multipart/form-data" method="POST" action="<?= base_url('/message/send') ?>">
                <div class="form-group row">
                    <label for="judul" class="col-sm-2 col-form-label">Judul</label>
                    <div class="col-sm-10">
                        <input type="text" name="judul" class="form-control" id="judul" placeholder="Masukkan judul permohonan" required autofocus>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="file" class="col-sm-2 col-form-label">Sisipkan File <div class="text-small text-danger">*optional</div></label>
                    <div class="col-sm-10">
                        <input type="file" class="form-control" id="file" name="file" placeholder="Sisipkan File">
                    </div>
                </div>
                <div class="form-group row">
                    <label for="pesan" class="col-sm-2 col-form-label">Pesan</label>
                    <div class="col-sm-10">
                        <textarea class="form-control" name="pesan" id="pesan" placeholder="Pesan permohonan" cols="30" rows="10" required></textarea>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-sm-10">
                        <button type="submit" class="btn btn-success">Kirim pesan</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>