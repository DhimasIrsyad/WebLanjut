<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Notifications extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('status') != "loggedin") {
            redirect(base_url("/"));
        }

        if ($this->session->userdata('role') == "user") {
            redirect(base_url("/dashboard"));
        }
        $this->load->model('M_notifications');
    }

    public function index()
    {
        $data['notifications'] = $this->M_notifications->getAll();

        $this->load->view('__header');
        $this->load->view('notifications/list-notif', $data);
        $this->load->view('__footer');
    }

    public function create()
    {
        $this->load->view('__header');
        $this->load->view('notifications/create-notif');
        $this->load->view('__footer');
    }

    public function store()
    {
        $this->load->helper(array('url'));

        $config['upload_path'] = './uploads/notifications';
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['max_size'] = '500000'; // max_size in kb 
        $config['file_name'] = time() . '-' . $_FILES['file']['name'];

        // Load upload library 
        $this->load->library('upload', $config);

        $payloadNotifications = [
            'gambar' => null,
        ];

        if ($this->upload->do_upload('file')) {
            // Get data about the file
            $uploadData = $this->upload->data();
            $filename = $uploadData['file_name'];
            $payloadNotifications['gambar'] = $filename;
        } else {
            $payloadNotifications['gambar'] = null;
        }

        $this->M_notifications->newNotif($payloadNotifications);
        $this->session->set_flashdata('new-notif', 'Berhasil membuat pemberitahuan');
        redirect(base_url('/notifications'));
    }

    public function edit()
    {
        $notifDetail = $this->M_notifications->detail($this->uri->segment('3'))->result();
        if (empty($notifDetail)) {
            $this->session->set_flashdata('new-notif', 'Gagal mengubah pemberitahuan');
            redirect(base_url('/notifications'));
        } else {
            $notifDetail = $notifDetail[0];
        }

        $data['notif'] = $notifDetail;

        $this->load->view('__header');
        $this->load->view('notifications/edit-notif', $data);
        $this->load->view('__footer');
    }

    public function update()
    {
        $notifDetail = $this->M_notifications->detail($this->uri->segment('3'))->result();
        if (empty($notifDetail)) {
            $this->session->set_flashdata('new-notif', 'Gagal mengubah pemberitahuan');
            redirect(base_url('/notifications'));
        } else {
            $notifDetail = $notifDetail[0];
        }

        $this->load->helper(array('url'));

        $config['upload_path'] = './uploads/notifications';
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['max_size'] = '500000'; // max_size in kb 
        $config['file_name'] = time() . '-' . $_FILES['file']['name'];

        // Load upload library 
        $this->load->library('upload', $config);

        $payloadNotifications = [
            'gambar' => $notifDetail->gambar,
            'deskripsi' => $this->input->post('deskripsi'),
        ];

        if (!empty($_FILES['file']['name'])) {

            if ($this->upload->do_upload('file')) {
                // Get data about the file
                $uploadData = $this->upload->data();
                $filename = $uploadData['file_name'];
                $payloadNotifications['gambar'] = $filename;
                $oldPathImage = base_url('/uploads/notifications/' . $notifDetail->gambar);

                if (file_exists($oldPathImage)) {
                    unlink($oldPathImage);
                }
            } else {
                $payloadNotifications['gambar'] = $notifDetail->gambar;
            }
        } else {
            $payloadNotifications['gambar'] = $notifDetail->gambar;
        }

        $this->M_notifications->updateNotif($notifDetail->id, $payloadNotifications);
        $this->session->set_flashdata('new-notif', 'Berhasil mengubah pemberitahuan');
        redirect(base_url('/notifications'));
    }

    public function delete()
    {
        $notifDetail = $this->M_notifications->detail($this->input->post('id'))->result();
        if (empty($notifDetail)) {
            $this->session->set_flashdata('new-notif', 'Gagal menghapus pemberitahuan');
            redirect(base_url('/notifications'));
        } else {
            $notifDetail = $notifDetail[0];
        }
        $imageNotif = base_url('/uploads/notifications/' . $notifDetail->gambar);

        if (file_exists($imageNotif)) {
            unlink($imageNotif);
        }

        $this->M_notifications->delete($notifDetail->id);
        $this->session->set_flashdata('new-notif', 'Berhasil menghapus pemberitahuan');
        redirect(base_url('/notifications'));
    }
}
