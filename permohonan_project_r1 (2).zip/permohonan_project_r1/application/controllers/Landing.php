<?php

class Landing extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('M_notifications');
    }

    public function index()
    {
        $data['notifications'] = $this->M_notifications->getAll();
        $this->load->view('landing/index', $data);
    }
}
