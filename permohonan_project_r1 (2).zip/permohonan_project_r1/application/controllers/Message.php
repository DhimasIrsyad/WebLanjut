<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Message extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('status') != "loggedin") {
            redirect(base_url("/"));
        }
        $this->load->model('M_message');
    }

    public function index()
    {
        $messages = $this->M_message->getAll();
        if ($this->session->userdata('role') != 'administrator') {
            $messages = $this->M_message->getMessageUserId($this->session->userdata('user_id'));
        }
        $data['messages'] = $messages;

        $this->load->view('__header');
        $this->load->view('message/list-message', $data);
        $this->load->view('__footer');
    }

    public function create()
    {
        if ($this->session->userdata('role') != "user") {
            redirect(base_url("/message"));
        }

        $this->load->view('__header');
        $this->load->view('message/create-message');
        $this->load->view('__footer');
    }

    public function send()
    {
        $this->load->helper(array('url'));

        $config['upload_path'] = './uploads/files';
        $config['allowed_types'] = 'gif|jpg|png|jpeg|pdf|word';
        $config['max_size'] = '500000'; // max_size in kb 
        $config['file_name'] = $_FILES['file']['name'];

        // Load upload library 
        $this->load->library('upload', $config);

        $payloadMessage = [
            'judul' => $this->input->post('judul'),
            'file' => null,
            'pesan' => $this->input->post('pesan'),
            'user_id' => $this->session->userdata('user_id'),
        ];

        if (!empty($_FILES['file']['name'])) {

            if ($this->upload->do_upload('file')) {
                // Get data about the file
                $uploadData = $this->upload->data();
                $filename = $uploadData['file_name'];
                $payloadMessage['file'] = $filename;
            } else {
                $payloadMessage['file'] = null;
            }
        } else {
            $payloadMessage['file'] = null;
        }

        $this->M_message->sendMessage($payloadMessage);
        $this->session->set_flashdata('sendMessage', 'Berhasil mengirim permohonan');
        redirect(base_url('/message'));
    }
}
