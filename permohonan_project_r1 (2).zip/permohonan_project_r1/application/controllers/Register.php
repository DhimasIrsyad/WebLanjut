<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {
	function __construct()
	{
		parent::__construct();		
		$this->load->model('M_login');
	}

	function index(){
		$this->load->view('register');
	}

	public function daftar()
	{	
		$this->load->helper(array('form', 'url'));

		$this->load->library('form_validation');

		$this->form_validation->set_rules('no_telp', 'Phone number', 'required|is_unique[user.no_telp]|min_length[10]', [
			'is_unique'     => 'this %s already exists'
		]);
		$this->form_validation->set_rules('password', 'Password', 'required');
		$this->form_validation->set_rules('passwordConfirmation', 'Password Confirmation', 'required|matches[password]');

		if ($this->form_validation->run() == FALSE) {
			$this->load->view('register');
		} else {
			$nama_lengkap = $this->input->post('nama_lengkap');
			$no_telp = $this->input->post('no_telp');
			$password = $this->input->post('password');

			$payloadUser = [
				'nama_lengkap' => $nama_lengkap,
				'password' => md5($password),
				'role' => 'user',
				'no_telp' => $no_telp,
			];

			$this->M_login->register($payloadUser);
			$this->session->set_flashdata('registerSuccess', 'Berhasil daftar, silahkan login untuk lanjut');
			redirect(base_url('/'));
		}
	}
}
