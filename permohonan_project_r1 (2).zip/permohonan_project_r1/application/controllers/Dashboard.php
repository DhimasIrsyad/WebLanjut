<?php 
 
class Dashboard extends CI_Controller{
 
	function __construct(){
		parent::__construct();
	
		if($this->session->userdata('status') != "loggedin"){
			redirect(base_url("/"));
		}
		$this->load->model('M_message');
		$this->load->model('M_login');
		$this->load->model('M_notifications');
	}
 
	function index(){

		$totalPermohonan = $this->M_message->getTotal();
		$totalWarga = $this->M_login->getTotal();
		$totalFile = $this->M_message->getTotalFile();
		$notifications = $this->M_notifications->getAll();

		$data = [
			'totalPermohonan' => $totalPermohonan,
			'totalWarga' => $totalWarga,
			'totalFile' => $totalFile,
			'notifications' => $notifications
		];

		$this->load->view('__header');
		if ($this->session->userdata('role') == "administrator") 
		{
			$this->load->view('dashboard_u', $data);
		} else {
			$this->load->view('dashboard_a', $data);
		}
		$this->load->view('__footer');
	}

}