<?php

class M_message extends CI_Model
{
    public function sendMessage($data)
    {
        return $this->db->insert('messages', $data);
    }

    public function getAll()
    {
        return $this->db->get('messages')->result();
    }

    public function getMessageUserId($userId)
    {
        return $this->db->where('user_id', $userId)->get('messages')->result();
    }

    public function getTotal()
    {
        return $this->db->count_all('messages');
    }

    public function getTotalFile()
    {
        return count($this->db->where('file !=', null)->get('messages')->result());
    }
}
