<?php

class M_login extends CI_Model
{
	function status($table, $where)
	{
		return $this->db->get_where($table, $where);
	}

	public function register($data)
	{
		return $this->db->insert('user', $data);
	}

	public function getTotal()
    {
        return $this->db->count_all('user');
    }
}
