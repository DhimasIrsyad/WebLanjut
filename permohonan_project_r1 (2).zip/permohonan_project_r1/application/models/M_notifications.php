<?php

class M_notifications extends CI_Model
{
    public function newNotif($data)
    {
        return $this->db->insert('notifications', $data);
    }

    public function getAll()
    {
        return $this->db->get('notifications')->result();
    }

    public function getTotal()
    {
        return $this->db->count_all('notifications');
    }

    public function detail($id)
    {
        return $this->db->where('id', $id)->get('notifications');
    }

    function delete($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('notifications');
    }

    public function updateNotif($id, $data)
    {
        $this->db->where('id', $id);
        $this->db->update('notifications', $data);
    }
}
